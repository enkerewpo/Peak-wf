#ifndef __WPROGRAM_H
#define	__WPROGRAM_H

#include "Arduino.h"

#endif
