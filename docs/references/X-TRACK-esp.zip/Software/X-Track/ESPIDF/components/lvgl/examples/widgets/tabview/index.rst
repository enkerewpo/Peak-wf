
Simple Tabview 
"""""""""""""""""""""""

.. lv_example:: widgets/tabview/lv_example_tabview_1
  :language: c

Tabs on the left, styling and no scrolling
"""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/tabview/lv_example_tabview_2
  :language: c


