
Simple List 
""""""""""""""""

.. lv_example:: widgets/list/lv_example_list_1
  :language: c

